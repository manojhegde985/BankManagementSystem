package com.example.bank.util;

public class BankUtil {

	public static final String SAVE = "/save";

	public static final String GET = "/getAll";

	public static final String HEALTH = "/healthcheck/{cid}";

	public static final String GETBYID = "/{cid}";
}
